<?php
/*Code to create causes element in visual composer
==================================================*/
add_action( 'vc_before_init', 'borntogive_causes_element' );
	function borntogive_causes_element() 
	{
		$terms = array();
		$campaign_cats = get_terms('campaign_category');
		if(!is_wp_error($campaign_cats))
		{
			foreach($campaign_cats as $cat)
			{ 
				$terms[] = array('value'=>$cat->term_id, 'label'=>$cat->name); 
			}
		}
		vc_map( array(
			"name" => __( "BORNTOGIVE Causes", "borntogive-vc" ),
			"base" => "borntogive_causes",
			'icon' => 'icon-wpb-vc_icon',
			"category" => __( "Born To Give", "borntogive-vc"),
			"class" => "",
			// 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
			// 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
			"params" => array(
				array(
					'type' => 'dropdown',
					'heading' => __( 'Causes/Campaigns View', 'borntogive-vc' ),
					'param_name' => 'causes_view',
					'value' => array( __( 'List', 'borntogive-vc' ) => 'list', __( 'Grid', 'borntogive-vc' ) => 'grid', __( 'Carousel', 'borntogive-vc' ) => 'carousel' ) ,
					'description' => __( 'Select causes view.', 'borntogive-vc' ),
					'param_holder_class' => 'vc_colored-dropdown',
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Grid Column', 'borntogive-vc' ),
					'param_name' => 'causes_grid_column',
					'value' => array( __( 'One Column', 'js_composer' ) => '12', __( 'Two Columns', 'borntogive-vc' ) => '6', __( 'Three Columns', 'borntogive-vc' ) => '4', __( 'Four Columns', 'borntogive-vc' ) => '3' ) ,
					'description' => __( 'Select Columns of grid/carousel.', 'borntogive-vc' ),
					'param_holder_class' => 'vc_colored-dropdown',
					'dependency' => array(
						'element' => 'causes_view',
						'value' => array( 'grid', 'carousel' ),
					),
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Show Excerpt', 'borntogive-vc' ),
					'param_name' => 'show_causes_excerpt',
					'value' => array( __( 'Yes', 'borntogive-vc' ) => '1', __( 'No', 'borntogive-vc' ) => '0') ,
					'param_holder_class' => 'vc_colored-dropdown',
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Show Pagination', 'borntogive-vc' ),
					'param_name' => 'show_causes_pagination',
					'value' => array( __( 'Yes', 'borntogive-vc' ) => 1, __( 'No', 'borntogive-vc' ) => 0) ,
					'param_holder_class' => 'vc_colored-dropdown',
				),
				array(
					'type' => 'checkbox',
					'heading' => __( 'Show Filters?', 'borntogive-vc' ),
					'param_name' => 'causes_filters',
					'description' => __( 'Show Filters for Causes/Campaigns.', 'borntogive-vc' ),
					'value' => array( __( 'Yes', 'borntogive-vc' ) => true ),
				),
				array(
					'type' 			=> 'autocomplete',
					'class' 		=> '',
					'heading' 		=> esc_html__( 'Causes/Campaign Categories', 'borntogive-vc' ),
					'param_name' 	=> 'causes_terms',
					'settings'		=> array( 'values' => $terms,'multiple' => true,
					'min_length' => 1,
					'groups' => true,
					// In UI show results grouped by groups, default false
					'unique_values' => true,
					// In UI show results except selected. NB! You should manually check values in backend, default false
					'display_inline' => true,
					// In UI show results inline view, default false (each value in own line)
					'delay' => 500,
					// delay for search. default 500
					'auto_focus' => true, ),
				),
				array(
					'type' => 'textfield',
					'holder' => 'div',
					'class' => '',
					'heading' => __( 'Number of Causes/Campaigns', 'borntogive-vc'),
					'param_name' => 'causes_number',
					'value' => 5,
					'description' => __( 'Insert number of causes/campaigns to show per page.', 'borntogive-vc' )
				),
			)
		) 
	);
}
/*Code to create element of Events for visual composer
=====================================================*/
add_action( 'vc_before_init', 'borntogive_events_element' );
	function borntogive_events_element() {
		$terms = array();
		$team_cats = get_terms('event-category');
		if(!is_wp_error($team_cats))
		{
			foreach($team_cats as $cat)
			{ 
				$terms[] = array('value'=>$cat->term_id, 'label'=>$cat->name); 
			}
		}
		vc_map( array(
			"name" => __( "BORNTOGIVE Events", "borntogive-vc" ),
			"base" => "borntogive_events",
			'icon' => 'icon-wpb-vc_icon',
			"category" => __( "Born To Give", "borntogive-vc"),
			"class" => "",
			// 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
			// 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
			"params" => array(
				array(
					'type' => 'dropdown',
					'heading' => __( 'Event Type', 'borntogive-vc' ),
					'param_name' => 'event_type',
					'value' => array( __( 'Future Events', 'borntogive-vc' ) => 'future', __( 'Past Events', 'borntogive-vc' ) => 'past' ) ,
					'description' => __( 'Select event type.', 'borntogive-vc' ),
					'param_holder_class' => 'vc_colored-dropdown',
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Event View', 'borntogive-vc' ),
					'param_name' => 'event_view',
					'value' => array( __( 'List', 'borntogive-vc' ) => 'list', __( 'Grid', 'borntogive-vc' ) => 'grid' ) ,
					'description' => __( 'Select event view.', 'borntogive-vc' ),
					'param_holder_class' => 'vc_colored-dropdown',
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Grid Column', 'borntogive-vc' ),
					'param_name' => 'event_grid_column',
					'value' => array( __( 'One Column', 'borntogive-vc' ) => '12', __( 'Two Columns', 'borntogive-vc' ) => '6', __( 'Three Columns', 'borntogive-vc' ) => '4', __( 'Four Columns', 'borntogive-vc' ) => '3' ) ,
					'description' => __( 'Select Columns of grid.', 'borntogive-vc' ),
					'param_holder_class' => 'vc_colored-dropdown',
					'dependency' => array(
						'element' => 'event_view',
						'value' => array( 'grid' ),
					),
				),
				array(
					'type' => 'checkbox',
					'heading' => __( 'Show Filters?', 'borntogive-vc' ),
					'param_name' => 'event_filters',
					'description' => __( 'Show Filters for Events Grid.', 'borntogive-vc' ),
					'value' => array( __( 'Yes', 'borntogive-vc' ) => true ),
					'dependency' => array(
						'element' => 'event_view',
						'value' => array( 'grid' ),
					),
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Show Excerpt', 'borntogive-vc' ),
					'param_name' => 'show_events_excerpt',
					'value' => array( __( 'Yes', 'borntogive-vc' ) => '1', __( 'No', 'borntogive-vc' ) => '0') ,
					'param_holder_class' => 'vc_colored-dropdown',
				),
				array(
					'type' => 'checkbox',
					'heading' => __( 'Show Pagination?', 'borntogive-vc' ),
					'param_name' => 'event_pagination',
					'description' => __( 'Show pagination for Events.', 'borntogive-vc' ),
					'value' => array( __( 'Yes', 'borntogive-vc' ) => true ),
				),
				array(
					'type' 			=> 'autocomplete',
					'class' 		=> '',
					'heading' 		=> esc_html__( 'Category Filter', 'borntogive-vc' ),
					'description' => __( 'Enter/Select event categories from which you would like to show events', 'borntogive-vc' ),
					'param_name' 	=> 'event_terms',
					'settings'		=> array( 'values' => $terms,'multiple' => true,
					'min_length' => 1,
					'groups' => true,
					// In UI show results grouped by groups, default false
					'unique_values' => true,
					// In UI show results except selected. NB! You should manually check values in backend, default false
					'display_inline' => true,
					// In UI show results inline view, default false (each value in own line)
					'delay' => 500,
					// delay for search. default 500
					'auto_focus' => true, ),
				),
				array(
					'type' => 'textfield',
					'holder' => 'div',
					'class' => '',
					'heading' => __( 'Number of Events', 'borntogive-vc'),
					'param_name' => 'event_number',
					'value' => 5,
					'description' => __( 'Insert number of events to show per page.', 'borntogive-vc')
				),
			)
		) 
	);
}
/*Code to create element of Gallery for visual composer
=====================================================*/
add_action( 'vc_before_init', 'borntogive_gallery_element' );
	function borntogive_gallery_element() {
		$terms = array();
		$team_cats = get_terms('gallery-category');
		if(!is_wp_error($team_cats))
		{
			foreach($team_cats as $cat)
			{ 
				$terms[] = array('value'=>$cat->term_id, 'label'=>$cat->name); 
			}
		}
		vc_map( array(
			"name" => __( "BORNTOGIVE Gallery", "borntogive-vc" ),
			"base" => "borntogive_gallery",
			'icon' => 'icon-wpb-vc_icon',
			"category" => __( "Born To Give", "borntogive-vc"),
			"class" => "",
			// 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
			// 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
			"params" => array(
				array(
					'type' => 'textfield',
					'holder' => 'div',
					'class' => '',
					'heading' => __( 'Title', 'borntogive-vc'),
					'param_name' => 'gallery_title',
					'value' => '',
					'description' => __( 'Insert Gallery title.', 'borntogive-vc')
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Gallery Type', 'borntogive-vc' ),
					'param_name' => 'gallery_type',
					'value' => array( __( 'Frame', 'borntogive-vc' ) => 'frame', __( 'Grid', 'borntogive-vc' ) => 'grid' ) ,
					'description' => __( 'Select gallery type.', 'borntogive-vc' ),
					'param_holder_class' => 'vc_colored-dropdown',
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Grid Column', 'borntogive-vc' ),
					'param_name' => 'gallery_grid_column',
					'value' => array( __( 'Two Columns', 'borntogive-vc' ) => 6, __( 'Three Column', 'borntogive-vc' ) => 4, __( 'Four Column', 'borntogive-vc' ) => 3 ) ,
					'description' => __( 'Select Columns of grid.', 'borntogive-vc' ),
					'param_holder_class' => 'vc_colored-dropdown',
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Gallery Caption', 'borntogive-vc' ),
					'param_name' => 'gallery_caption',
					'value' => array( __( 'Yes', 'borntogive-vc' ) => '', __( 'No', 'borntogive-vc' ) => '0') ,
					'description' => __( 'Show gallery caption?', 'borntogive-vc' ),
					'param_holder_class' => 'vc_colored-dropdown',
					'dependency' => array(
						'element' => 'gallery_type',
						'value' => array( 'grid' ),
					),
				),
				array(
					'type' => 'checkbox',
					'heading' => __( 'Show Filters?', 'borntogive-vc' ),
					'param_name' => 'gallery_filters',
					'description' => __( 'Show filters for Gallery.', 'borntogive-vc' ),
					'value' => array( __( 'Yes', 'borntogive-vc' ) => true ),
				),
				array(
					'type' 			=> 'autocomplete',
					'class' 		=> '',
					'heading' 		=> esc_html__( 'Gallery Categories', 'borntogive-vc' ),
					'param_name' 	=> 'gallery_terms',
					'settings'		=> array( 'values' => $terms,'multiple' => true,
					'min_length' => 1,
					'groups' => true,
					// In UI show results grouped by groups, default false
					'unique_values' => true,
					// In UI show results except selected. NB! You should manually check values in backend, default false
					'display_inline' => true,
					// In UI show results inline view, default false (each value in own line)
					'delay' => 500,
					// delay for search. default 500
					'auto_focus' => true, ),
				),
				array(
					'type' => 'textfield',
					'holder' => 'div',
					'class' => '',
					'heading' => __( 'Number of Gallery', 'borntogive-vc' ),
					'param_name' => 'gallery_number',
					'value' => 5,
					'description' => __( 'Insert number of gallery to show per page.', 'borntogive-vc' )
				),
			)
		) 
	);
}
/*Code to create element of Testimonial for visual composer
=====================================================*/
add_action( 'vc_before_init', 'borntogive_testimonial_element' );
	function borntogive_testimonial_element() {
		$terms = array();
		$testi_cats = get_terms('testimonial-category');
		if(!is_wp_error($testi_cats))
		{
			foreach($testi_cats as $cat)
			{ 
				$terms[] = array('value'=>$cat->term_id, 'label'=>$cat->name); 
			}
		}
		vc_map( array(
			"name" => __( "BORNTOGIVE Testimonial", "borntogive-vc" ),
			"base" => "borntogive_testimonial",
			'icon' => 'icon-wpb-vc_icon',
			"category" => __( "Born To Give", "borntogive-vc"),
			"class" => "",
			"params" => array(
				 array(
					'type' => 'dropdown',
					'heading' => __( 'Testimonial View', 'borntogive-vc' ),
					'param_name' => 'testimonial_view',
					'value' => array( __( 'Type 1', 'borntogive-vc' ) => '1', __( 'Type 2', 'borntogive-vc' ) => '2' ) ,
					'description' => __( 'Select testimonial view.', 'borntogive-vc' ),
					'param_holder_class' => 'vc_colored-dropdown',
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Carousel Column', 'borntogive-vc' ),
					'param_name' => 'testimonial_carousel_column',
					'value' => array( __( 'One Column', 'borntogive-vc' ) => '1',__( 'Two Columns', 'borntogive-vc' ) => '2', __( 'Three Column', 'borntogive-vc' ) => '3', __( 'Four Column', 'borntogive-vc' ) => '4', __( 'Five Column', 'borntogive-vc' ) => '5', __( 'Six Column', 'borntogive-vc' ) => '6' ) ,
					'description' => __( 'Select Columns of carousel.', 'borntogive-vc' ),
					'param_holder_class' => 'vc_colored-dropdown',
				),
				array(
					'type' 			=> 'autocomplete',
					'class' 		=> '',
					'heading' 		=> esc_html__( 'Testimonial Categories', 'borntogive-vc' ),
					'param_name' 	=> 'testimonial_terms',
					'settings'		=> array( 'values' => $terms,'multiple' => true,
					'min_length' => 1,
					'groups' => true,
					// In UI show results grouped by groups, default false
					'unique_values' => true,
					// In UI show results except selected. NB! You should manually check values in backend, default false
					'display_inline' => true,
					// In UI show results inline view, default false (each value in own line)
					'delay' => 500,
					// delay for search. default 500
					'auto_focus' => true, ),
				),
				array(
					 'type' => 'textfield',
					 'holder' => 'div',
					 'class' => '',
					 'heading' => __( 'Number of Testimonials', 'borntogive-vc' ),
					 'param_name' => 'testimonial_number',
					 'value' => 5,
					 'description' => __( 'Insert number of gallery to show per page.', 'borntogive-vc' )
				),
			)
		) 
	);
}
/*Code to create element of Posts for visual composer
=====================================================*/
add_action( 'vc_before_init', 'borntogive_post_element' );
	function borntogive_post_element() {
		$terms = array();
		$posts_cats = get_terms('category');
		if(!is_wp_error($posts_cats))
		{
			foreach($posts_cats as $cat)
			{ 
				$terms[] = array('value'=>$cat->term_id, 'label'=>$cat->name); 
			}
		}
		vc_map( array(
			"name" => __( "BORNTOGIVE Posts", "borntogive-vc" ),
			"base" => "borntogive_post",
			'icon' => 'icon-wpb-vc_icon',
			"category" => __( "Born To Give", "borntogive-vc"),
			"class" => "",
			// 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
			// 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
			"params" => array(
				array(
					'type' => 'dropdown',
					'heading' => __( 'Post View', 'borntogive-vc' ),
					'param_name' => 'post_view',
					'value' => array( __( 'List', 'borntogive-vc' ) => 'list', __( 'Grid', 'borntogive-vc' ) => 'grid', __( 'Grid with Carousel', 'borntogive-vc' ) => 'carousel' ) ,
					'description' => __( 'Select post view.', 'borntogive-vc' ),
					'param_holder_class' => 'vc_colored-dropdown',
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Grid Column', 'borntogive-vc' ),
					'param_name' => 'post_grid_column',
					'value' => array( __( 'Two Columns', 'borntogive-vc' ) => '6', __( 'Three Columns', 'borntogive-vc' ) => '4', __( 'Four Columns', 'borntogive-vc' ) => '3' ) ,
					'description' => __( 'Select Columns of grid.', 'borntogive-vc' ),
					'param_holder_class' => 'vc_colored-dropdown',
					'dependency' => array(
						'element' => 'post_view',
						'value' => array( 'grid' ),
					),
				),
				array(
					'type' => 'autocomplete',
					'class' => '',
					'heading' => __( 'Post Categories', 'borntogive-vc' ),
					'param_name' => 'post_terms',
					'description' => __( 'Insert post categories slug by comma "," separated.', 'borntogive-vc' ),
					'settings'		=> array( 'values' => $terms,'multiple' => true,
					'min_length' => 1,
					'groups' => true,
					// In UI show results grouped by groups, default false
					'unique_values' => true,
					// In UI show results except selected. NB! You should manually check values in backend, default false
					'display_inline' => true,
					// In UI show results inline view, default false (each value in own line)
					'delay' => 500,
					// delay for search. default 500
					'auto_focus' => true, ),
				),
				array(
					'type' => 'textfield',
					'holder' => 'div',
					'class' => '',
					'heading' => __( 'Number of Posts', 'borntogive-vc' ),
					'param_name' => 'post_number',
					'value' => 5,
					'description' => __( 'Insert number of posts to show per page.', 'borntogive-vc' )
				),
				array(
					'type' => 'checkbox',
					'heading' => __( 'Show Pagination?', 'borntogive-vc' ),
					'param_name' => 'posts_pagination',
					'description' => __( 'Show pagination for Posts.', 'borntogive-vc' ),
					'value' => array( __( 'Yes', 'borntogive-vc' ) => true ),
				),
			)
		) 
	);
}
/*Code to create element of Grid Container for visual composer
=====================================================*/
//add_action( 'vc_before_init', 'borntogive_gridcontainer_element' );
	function borntogive_gridcontainer_element() {
		vc_map( array(
			"name" => __( "BORNTOGIVE Grid Container", "borntogive-vc" ),
			"base" => "borntogive_gridcontainer",
			'icon' => 'icon-wpb-vc_icon',
			"category" => __( "Born To Give", "borntogive-vc"),
			"class" => "",
			// 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
			// 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
			"params" => array(
				array(
					'type' => 'attach_image',
					 'holder' => 'div',
					 'class' => 'page-header-container',
					 'heading' => __( 'Background Image', 'borntogive-vc' ),
					 'param_name' => 'grid_image',
					 'value' => '',
					 'description' => __( 'Choose a grid image', 'borntogive-vc' )
				),
				array(
					'type' => 'textarea',
					'holder' => 'div',
					'class' => '',
					'heading' => __( 'Grid Description', 'borntogive-vc' ),
					'param_name' => 'grid_description',
					'value' => __( '' ),
					'description' => __( 'Enter grid description.', 'borntogive-vc' )
				),
				array(
					'type' => 'textfield',
					'holder' => 'div',
					'class' => '',
					'heading' => __( 'Grid URL', 'borntogive-vc' ),
					'param_name' => 'grid_url',
					'value' => '',
					'description' => __( 'Enter grid URL.', 'borntogive-vc' )
				),
			)
		) 
	);
}

/*Code to create element of Team for visual composer
=====================================================*/
add_action( 'vc_before_init', 'borntogive_team_element' );
	function borntogive_team_element() {
		$terms = array();
		$team_cats = get_terms('team-category');
		if(!is_wp_error($team_cats))
		{
			foreach($team_cats as $cat)
			{ 
				$terms[] = array('value'=>$cat->term_id, 'label'=>$cat->name); 
			}
		}
		vc_map( array(
			"name" => __( "BORNTOGIVE Team", "borntogive-vc" ),
			"base" => "borntogive_team",
			'icon' => 'icon-wpb-vc_icon',
			"category" => __( "Born To Give", "borntogive-vc"),
			"class" => "",
			// 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
			// 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
			"params" => array(
				array(
					'type' => 'textfield',
					'holder' => 'div',
					'class' => '',
					'heading' => __( 'Number of Team Members', 'borntogive-vc' ),
					'param_name' => 'team_number',
					'value' => 3,
					'description' => __( 'Insert number of team members to show.', 'borntogive-vc' )
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Show Details?', 'borntogive-vc' ),
					'param_name' => 'team_details',
					'description' => __( 'Show team member details.', 'borntogive-vc' ),
					'value' => array( __( 'Yes', 'borntogive-vc' ) => '1', __( 'No', 'borntogive-vc' ) => '0' ) ,
					'param_holder_class' => 'vc_colored-dropdown',
				),
				array(
					'type' => 'textfield',
					'holder' => 'div',
					'class' => '',
					'heading' => __( 'Number of Words to show as excerpt', 'borntogive-vc' ),
					'param_name' => 'team_excerpt',
					'value' => 30,
					'description' => __( 'This is the number of words that will be shown for the team member content. This text comes from the team post content or excerpt field.', 'borntogive-vc' )
				),
				array(
					'type' => 'textfield',
					'holder' => 'div',
					'class' => '',
					'heading' => __( 'Excerpt closing text', 'borntogive-vc' ),
					'param_name' => 'team_closing_text',
					'value' => '...',
					'description' => __( 'Enter the text that you would like to show just after the limited content ends. Default is ...', 'borntogive-vc' )
				),
				array(
					'type' => 'textfield',
					'holder' => 'div',
					'class' => '',
					'heading' => __( 'Read more link text', 'borntogive-vc' ),
					'param_name' => 'team_more_text',
					'value' => '',
					'description' => __( 'Enter the link text which will be shown after the limited content/excerpt.', 'borntogive-vc' )
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Activate Carousel?', 'borntogive-vc' ),
					'param_name' => 'team_carousel',
					'description' => __( 'Activate carousel for team.', 'borntogive-vc' ),
					'value' => array( __( 'Yes', 'js_composer' ) => '1', __( 'No', 'borntogive-vc' ) => '0') ,
					'param_holder_class' => 'vc_colored-dropdown',
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Column Style', 'borntogive-vc' ),
					'param_name' => 'team_carousel_column',
					'value' => array( __( 'Two Columns', 'borntogive-vc' ) => '2', __( 'Three Columns', 'borntogive-vc' ) => '3', __( 'Four Columns', 'borntogive-vc' ) => '4', __( 'Five Columns', 'borntogive-vc' ) => '5', __( 'Six Columns', 'borntogive-vc' ) => '6' ) ,
					'description' => __( 'Select Columns of carousel/grid.', 'borntogive-vc' ),
					'param_holder_class' => 'vc_colored-dropdown',
				),
				array(
					'type' 			=> 'autocomplete',
					'class' 		=> '',
					'heading' 		=> esc_html__( 'Team Categories', 'borntogive-vc' ),
					'param_name' 	=> 'team_terms',
					'settings'		=> array( 'values' => $terms,'multiple' => true,
					'min_length' => 1,
					'groups' => true,
					// In UI show results grouped by groups, default false
					'unique_values' => true,
					// In UI show results except selected. NB! You should manually check values in backend, default false
					'display_inline' => true,
					// In UI show results inline view, default false (each value in own line)
					'delay' => 500,
					// delay for search. default 500
					'auto_focus' => true, ),
				),
			)
		) 
	);
}
/*Code to create element of Featured Link for visual composer
=====================================================*/
add_action( 'vc_before_init', 'borntogive_featured_link' );
	function borntogive_featured_link() {
		vc_map( array(
			"name" => __( "BORNTOGIVE Featured Link", "borntogive-vc" ),
			"base" => "borntogive_feat_link",
			'icon' => 'icon-wpb-vc_icon',
			"category" => __( "Born To Give", "borntogive-vc"),
			"class" => "",
			// 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
			// 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
			"params" => array(
				array(
					'type' => 'textfield',
					'holder' => 'div',
					'class' => '',
					'heading' => __( 'Title', 'borntogive-vc' ),
					'param_name' => 'feat_title',
					'value' => '',
					'description' => __( 'Insert title for featured link.', 'borntogive-vc' )
				),
				array(
					'type' => 'textfield',
					'holder' => 'div',
					'class' => '',
					'heading' => __( 'Sub title', 'borntogive-vc' ),
					'param_name' => 'feat_head_line',
					'value' => __( '' ),
					'description' => __( 'Insert sub title for featured link.', 'borntogive-vc' )
				),
				array(
					'type' => 'textfield',
					'holder' => 'div',
					'class' => '',
					'heading' => __( 'URL', 'borntogive-vc' ),
					'param_name' => 'feat_url',
					'value' => '',
					'description' => __( 'Insert URL for featured link.', 'borntogive-vc' )
				),
				array(
					'type' => 'colorpicker',
					'class' => '',
					'heading' => __( 'Background Color', 'borntogive-vc' ),
					'param_name' => 'feat_custom_bg',
					'description' => __( 'Select custom background color for the featured link block. By default it will be a darker shade of your selected theme color scheme/custom color at Theme Options.', 'borntogive-vc' )
				),
				array(
					'type' => 'colorpicker',
					'class' => '',
					'heading' => __( 'Text Color', 'borntogive-vc' ),
					'param_name' => 'feat_custom_text',
					'description' => __( 'Select custom text color for the featured link block. By default it is #ffffff.', 'borntogive-vc' )
				),
			)
		) 
	);
}
/*Code to create element of Featured Text for visual composer
=====================================================*/
add_action( 'vc_before_init', 'borntogive_featured_text' );
	function borntogive_featured_text() {
		vc_map( array(
			"name" => __( "BORNTOGIVE Featured Text", "borntogive-vc" ),
			"base" => "borntogive_feat_text",
			'icon' => 'icon-wpb-vc_icon',
			"category" => __( "Born To Give", "borntogive-vc"),
			"class" => "",
			// 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
			// 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
			"params" => array(
				array(
					'type' => 'textfield',
					'holder' => 'div',
					'class' => '',
					'heading' => __( 'Head Line', 'borntogive-vc' ),
					'param_name' => 'feat_head',
					'value' => __( '' ),
					'description' => __( 'Insert head line for featured text."," separated.', 'borntogive-vc' )
				),
				array(
					'type' => 'textfield',
					'holder' => 'div',
					'class' => '',
					'heading' => __( 'Content', 'borntogive-vc' ),
					'param_name' => 'feat_content',
					'value' => '',
					'description' => __( 'Insert content for featured text.', 'borntogive-vc' )
				 ),
			)
		) 
	);
}